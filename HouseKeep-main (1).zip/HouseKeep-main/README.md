# HouseKeep
<<<<<<< HEAD

# AEC Gensler Hackathon Project
=======
AEC Gensler Hackathon Project

Abigail Hartzell
Astrid Vargas
Enkela Tafa
Jero Franco
Kaitlyn Phan
>>>>>>> cde7b051d3decc0cd7e890b1cdc92fc03ea0d270
